package com.galera.app.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.galera.app.data.Photo
import kotlin.math.abs

/**
 * Один экран для двух сценариев:
 *  - создание коллекции ([showName] = true): шаг 1 — выбор фото, шаг 2 — название и цвет
 *    с красивой «раздачей» карточек;
 *  - добавление фото в существующую коллекцию ([showName] = false): только шаг 1.
 */
@Composable
fun PickPhotosScreen(
    title: String,
    showName: Boolean,
    confirmLabel: String,
    photos: List<Photo>,
    onClose: () -> Unit,
    onConfirm: (name: String, ids: List<Long>, accentIndex: Int) -> Unit,
) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    var name by rememberSaveable { mutableStateOf("") }
    var accent by rememberSaveable { mutableIntStateOf(1) }
    val selected = rememberSaveable(
        saver = listSaver<SnapshotStateList<Long>, Long>(
            save = { it.toList() },
            restore = { it.toMutableStateList() },
        ),
    ) { mutableListOf<Long>().toMutableStateList() }
    val byId = remember(photos) { photos.associateBy { it.id } }

    BackHandler(enabled = step == 1) { step = 0 }

    AnimatedContent(
        targetState = step,
        transitionSpec = { fadeIn(tween(320)) togetherWith fadeOut(tween(200)) },
        label = "pickStep",
    ) { s ->
        if (s == 0) {
            PickStep(
                title = title,
                actionLabel = if (showName) "Далее" else confirmLabel,
                photos = photos,
                selected = selected,
                onClose = onClose,
                onAction = {
                    if (showName) step = 1 else onConfirm("", selected.toList(), accent)
                },
            )
        } else {
            NameStep(
                uris = selected.mapNotNull { byId[it]?.uri },
                count = selected.size,
                name = name,
                onName = { name = it },
                accent = accent,
                onAccent = { accent = it },
                onBack = { step = 0 },
                onCreate = { onConfirm(name.trim().ifBlank { "Новая коллекция" }, selected.toList(), accent) },
            )
        }
    }
}

// ───────────────────────── шаг 1: выбор фото ─────────────────────────

@Composable
private fun PickStep(
    title: String,
    actionLabel: String,
    photos: List<Photo>,
    selected: SnapshotStateList<Long>,
    onClose: () -> Unit,
    onAction: () -> Unit,
) {
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlassButton(onClick = onClose) {
                    Icon(Icons.Rounded.Close, "Закрыть", tint = Color.White)
                }
                Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                    Text(title, style = MaterialTheme.typography.titleLarge)
                    Text(
                        if (selected.isEmpty()) "Выберите фото" else "Выбрано: ${selected.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (photos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Нет подходящих фото", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 3.dp, end = 3.dp, top = 4.dp, bottom = 130.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    items(photos, key = { it.id }) { photo ->
                        PickTile(
                            uri = photo.uri,
                            order = selected.indexOf(photo.id),
                            onClick = {
                                if (!selected.remove(photo.id)) selected.add(photo.id)
                            },
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = selected.isNotEmpty(),
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it },
        ) {
            PrimaryPill(
                "$actionLabel · ${selected.size}",
                onAction,
                Modifier.navigationBarsPadding().padding(bottom = 20.dp),
            )
        }
    }
}

@Composable
private fun PickTile(uri: Uri, order: Int, onClick: () -> Unit) {
    val isSelected = order >= 0
    val scale by animateFloatAsState(
        if (isSelected) 0.86f else 1f,
        spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "tileScale",
    )
    Box(
        Modifier
            .aspectRatio(1f)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
    ) {
        PhotoImage(
            uri,
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .clip(RoundedCornerShape(if (isSelected) 14.dp else 4.dp)),
            px = 320,
        )
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .size(24.dp)
                .clip(CircleShape)
                .then(
                    if (isSelected) Modifier.background(Color.White)
                    else Modifier.background(Color.Black.copy(alpha = 0.25f)).border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape),
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (isSelected) {
                Text("${order + 1}", color = Color.Black, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ───────────────────────── шаг 2: название и цвет ─────────────────────────

@Composable
private fun NameStep(
    uris: List<Uri>,
    count: Int,
    name: String,
    onName: (String) -> Unit,
    accent: Int,
    onAccent: (Int) -> Unit,
    onBack: () -> Unit,
    onCreate: () -> Unit,
) {
    val accentColor by animateColorAsState(Accents[accent % Accents.size], tween(500), label = "accentBg")
    val focus = LocalFocusManager.current
    val textStyle = TextStyle(
        color = Color.White,
        fontFamily = Display,
        fontWeight = FontWeight.SemiBold,
        fontSize = 32.sp,
        textAlign = TextAlign.Center,
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(accentColor.copy(alpha = 0.42f), GaleraBg), endY = 1600f)),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад", tint = Color.White)
                }
            }

            DealtFan(uris, Modifier.padding(top = 8.dp))

            Spacer(Modifier.height(20.dp))
            BasicTextField(
                value = name,
                onValueChange = { if (it.length <= 40) onName(it) },
                singleLine = true,
                textStyle = textStyle,
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { focus.clearFocus() }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        if (name.isEmpty()) {
                            Text("Назовите коллекцию", style = textStyle.copy(color = Color.White.copy(alpha = 0.35f)))
                        }
                        inner()
                    }
                },
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "$count фото",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.6f),
            )

            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Accents.forEachIndexed { index, color ->
                    val ring = if (index == accent) Color.White else Color.Transparent
                    Box(
                        Modifier
                            .size(42.dp)
                            .border(2.dp, ring, CircleShape)
                            .padding(5.dp)
                            .clip(CircleShape)
                            .background(color)
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                                onAccent(index)
                            },
                    )
                }
            }

            Spacer(Modifier.height(32.dp))
            PrimaryPill("Создать коллекцию", onCreate, Modifier.fillMaxWidth().padding(horizontal = 24.dp))
            Spacer(Modifier.height(20.dp))
        }
    }
}

/** Выбранные фото «раздаются» из-под экрана веером с небольшой задержкой между карточками. */
@Composable
private fun DealtFan(uris: List<Uri>, modifier: Modifier = Modifier) {
    val shown = remember(uris) { uris.takeLast(6) }
    val n = shown.size
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { progress.animateTo(1f, tween(1200, easing = LinearEasing)) }

    Box(modifier.fillMaxWidth().height(310.dp), contentAlignment = Alignment.Center) {
        shown.forEachIndexed { i, uri ->
            PhotoCard(
                uri,
                Modifier
                    .zIndex(i.toFloat())
                    .size(184.dp, 250.dp)
                    .graphicsLayer {
                        val t = FastOutSlowInEasing.transform(((progress.value * (n + 1)) - i).coerceIn(0f, 1f))
                        val rel = i - (n - 1) / 2f
                        translationX = rel * 34.dp.toPx() * t
                        translationY = abs(rel) * 10.dp.toPx() * t + (1f - t) * 460.dp.toPx()
                        rotationZ = rel * 7f * t
                        alpha = (t * 4f).coerceIn(0f, 1f)
                    },
                corner = 26.dp,
                px = 700,
                elevation = 16.dp,
            )
        }
    }
}
