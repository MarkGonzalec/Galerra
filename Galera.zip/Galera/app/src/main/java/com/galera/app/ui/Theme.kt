package com.galera.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Акценты коллекций — приглушённые пастельные цвета, хорошо смотрятся на тёмном фоне. */
val Accents = listOf(
    Color(0xFFFF8A80),
    Color(0xFF8C9EFF),
    Color(0xFF80CBC4),
    Color(0xFFFFD180),
    Color(0xFFCE93D8),
    Color(0xFF81D4FA),
)

val GaleraBg = Color(0xFF09090B)
val GaleraPill = Color(0xFF1B1B20)

/** Засечный шрифт для крупных заголовков (как «Japan» и «Pool» в референсах). */
val Display = FontFamily.Serif

private val DarkColors = darkColorScheme(
    primary = Color(0xFFF2F2F5),
    onPrimary = Color(0xFF09090B),
    background = GaleraBg,
    onBackground = Color(0xFFF2F2F5),
    surface = Color(0xFF17171B),
    onSurface = Color(0xFFF2F2F5),
    surfaceVariant = Color(0xFF232329),
    onSurfaceVariant = Color(0xFF9A9AA5),
    outline = Color(0xFF3A3A42),
)

private val GaleraTypography = Typography(
    headlineLarge = TextStyle(fontFamily = Display, fontWeight = FontWeight.SemiBold, fontSize = 34.sp),
    headlineMedium = TextStyle(fontFamily = Display, fontWeight = FontWeight.SemiBold, fontSize = 28.sp),
    titleLarge = TextStyle(fontFamily = Display, fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 17.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    bodySmall = TextStyle(fontSize = 12.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
)

@Composable
fun GaleraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, typography = GaleraTypography, content = content)
}
