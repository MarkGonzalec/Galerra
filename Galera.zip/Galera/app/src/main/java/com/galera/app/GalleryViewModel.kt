package com.galera.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.galera.app.data.Album
import com.galera.app.data.AlbumStore
import com.galera.app.data.MediaRepository
import com.galera.app.data.Photo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MediaRepository(app)
    private val store = AlbumStore(app)

    private val _photos = MutableStateFlow<List<Photo>>(emptyList())
    val photos: StateFlow<List<Photo>> = _photos.asStateFlow()

    private val _albums = MutableStateFlow(store.load())
    val albums: StateFlow<List<Album>> = _albums.asStateFlow()

    fun refresh() {
        viewModelScope.launch { _photos.value = repo.loadPhotos() }
    }

    fun createAlbum(name: String, ids: List<Long>, accentIndex: Int): String {
        val album = Album(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            createdAt = System.currentTimeMillis(),
            accentIndex = accentIndex,
            photoIds = ids,
        )
        update { listOf(album) + it }
        return album.id
    }

    fun addPhotos(albumId: String, ids: List<Long>) = modify(albumId) {
        it.copy(photoIds = (it.photoIds + ids).distinct())
    }

    fun removePhoto(albumId: String, photoId: Long) = modify(albumId) {
        it.copy(photoIds = it.photoIds - photoId)
    }

    fun rename(albumId: String, name: String) = modify(albumId) {
        it.copy(name = name.trim().ifEmpty { it.name })
    }

    fun deleteAlbum(albumId: String) = update { list -> list.filterNot { it.id == albumId } }

    private fun modify(albumId: String, transform: (Album) -> Album) = update { list ->
        list.map { if (it.id == albumId) transform(it) else it }
    }

    private fun update(transform: (List<Album>) -> List<Album>) {
        _albums.value = transform(_albums.value)
        store.save(_albums.value)
    }
}
