package com.galera.app.ui

import android.net.Uri
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.galera.app.data.Album
import com.galera.app.data.Photo

@Composable
fun AlbumsScreen(
    albums: List<Album>,
    photos: List<Photo>,
    onOpen: (String) -> Unit,
    onCreate: () -> Unit,
    onAddPhotos: (String) -> Unit,
) {
    val byId = remember(photos) { photos.associateBy { it.id } }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 16.dp)) {
            Text(
                "Galera",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground,
            )
            if (albums.isNotEmpty()) {
                Text(
                    "${albums.size} ${plural(albums.size, "коллекция", "коллекции", "коллекций")} · ${photos.size} фото",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (albums.isEmpty()) {
            EmptyState(photos, onCreate)
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 150.dp),
                verticalArrangement = Arrangement.spacedBy(30.dp),
            ) {
                items(albums, key = { it.id }) { album ->
                    val items = remember(album, byId) { album.photoIds.mapNotNull { byId[it] } }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { onOpen(album.id) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        CoverRow(
                            uris = items.map { it.uri },
                            total = items.size,
                            accent = Accents[album.accentIndex % Accents.size],
                            onAdd = { onAddPhotos(album.id) },
                        )
                        Spacer(Modifier.height(14.dp))
                        Text(
                            album.name,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "${formatDate(album.createdAt)} · ${items.size} фото",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(photos: List<Photo>, onCreate: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(bottom = 90.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 32.dp)) {
            CardFan(uris = photos.take(3).map { it.uri })
            Spacer(Modifier.height(36.dp))
            Text(
                "Всё начинается\nс коллекции",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Создайте первую, чтобы собрать любимые воспоминания",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(28.dp))
            PrimaryPill("Создать первую коллекцию", onCreate)
        }
    }
}

/** Три наклонённые карточки, «веером» выезжающие из стопки. Без фото — цветные заглушки. */
@Composable
fun CardFan(uris: List<Uri>, modifier: Modifier = Modifier) {
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        appear.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessVeryLow))
    }
    val rotations = listOf(-11f, 9f, -1f)
    val shifts = listOf(-62, 62, 0)
    val lifts = listOf(10, 6, -6)
    Box(modifier.height(240.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
        for (i in 0 until 3) {
            val cardMod = Modifier
                .zIndex(i.toFloat())
                .size(150.dp, 206.dp)
                .offset(x = shifts[i].dp, y = lifts[i].dp)
                .graphicsLayer {
                    rotationZ = rotations[i] * appear.value
                    translationX = shifts[i].dp.toPx() * (appear.value - 1f)
                }
            val uri = uris.getOrNull(i)
            if (uri != null) PhotoCard(uri, cardMod, corner = 24.dp, px = 500)
            else PlaceholderCard(Accents[(i * 2 + 1) % Accents.size], cardMod, corner = 24.dp)
        }
    }
}

fun plural(n: Int, one: String, few: String, many: String): String {
    val m100 = n % 100
    val m10 = n % 10
    return when {
        m100 in 11..14 -> many
        m10 == 1 -> one
        m10 in 2..4 -> few
        else -> many
    }
}
