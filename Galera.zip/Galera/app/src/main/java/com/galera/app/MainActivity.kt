package com.galera.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.galera.app.ui.AlbumScreen
import com.galera.app.ui.AlbumsScreen
import com.galera.app.ui.CardFan
import com.galera.app.ui.GaleraBg
import com.galera.app.ui.GaleraTheme
import com.galera.app.ui.PhotosScreen
import com.galera.app.ui.PickPhotosScreen
import com.galera.app.ui.PillSwitch
import com.galera.app.ui.PrimaryPill
import com.galera.app.ui.ViewerScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
        )
        setContent {
            GaleraTheme {
                Box(Modifier.fillMaxSize().background(GaleraBg)) {
                    GalleryApp()
                }
            }
        }
    }
}

// ───────────────────────── разрешения ─────────────────────────

private fun mediaPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 34 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
    )
    Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

/** На Android 14+ достаточно и «выбранных фото» (частичный доступ). */
private fun hasMediaAccess(context: Context): Boolean {
    fun granted(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED
    return when {
        Build.VERSION.SDK_INT >= 34 ->
            granted(Manifest.permission.READ_MEDIA_IMAGES) || granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 -> granted(Manifest.permission.READ_MEDIA_IMAGES)
        else -> granted(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
}

// ───────────────────────── приложение ─────────────────────────

@Composable
private fun GalleryApp(vm: GalleryViewModel = viewModel()) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasMediaAccess(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasMediaAccess(context)
        if (granted) vm.refresh()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasMediaAccess(context)
        if (granted) vm.refresh()
    }

    if (!granted) {
        PermissionScreen { launcher.launch(mediaPermissions()) }
        return
    }

    val photos by vm.photos.collectAsState()
    val albums by vm.albums.collectAsState()
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val showBar = route == "albums" || route == "photos"

    Box(Modifier.fillMaxSize()) {
        NavHost(
            navController = nav,
            startDestination = "albums",
            enterTransition = { fadeIn(tween(280)) + scaleIn(tween(280), initialScale = 0.96f) },
            exitTransition = { fadeOut(tween(200)) },
            popEnterTransition = { fadeIn(tween(240)) },
            popExitTransition = { fadeOut(tween(220)) + scaleOut(tween(220), targetScale = 0.96f) },
        ) {

            composable("albums") {
                AlbumsScreen(
                    albums = albums,
                    photos = photos,
                    onOpen = { nav.navigate("album/$it") },
                    onCreate = { nav.navigate("create") },
                    onAddPhotos = { nav.navigate("add/$it") },
                )
            }

            composable("photos") {
                PhotosScreen(photos = photos, onOpen = { nav.navigate("viewer/all/$it") })
            }

            composable("create") {
                PickPhotosScreen(
                    title = "Новая коллекция",
                    showName = true,
                    confirmLabel = "Создать",
                    photos = photos,
                    onClose = { nav.popBackStack() },
                    onConfirm = { name, ids, accent ->
                        val id = vm.createAlbum(name, ids, accent)
                        nav.navigate("album/$id") { popUpTo("create") { inclusive = true } }
                    },
                )
            }

            composable(
                "album/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType }),
            ) { entry ->
                val id = entry.arguments?.getString("id").orEmpty()
                val album = albums.firstOrNull { it.id == id }
                if (album == null) {
                    // коллекцию удалили — выходим
                    LaunchedEffect(Unit) { nav.popBackStack() }
                } else {
                    val albumPhotos = remember(album, photos) {
                        val byId = photos.associateBy { it.id }
                        album.photoIds.mapNotNull { byId[it] }
                    }
                    AlbumScreen(
                        album = album,
                        photos = albumPhotos,
                        onBack = { nav.popBackStack() },
                        onOpenPhoto = { nav.navigate("viewer/$id/$it") },
                        onAddPhotos = { nav.navigate("add/$id") },
                        onRename = { vm.rename(id, it) },
                        onDelete = { vm.deleteAlbum(id) },
                    )
                }
            }

            composable(
                "add/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType }),
            ) { entry ->
                val id = entry.arguments?.getString("id").orEmpty()
                val album = albums.firstOrNull { it.id == id }
                val available = remember(album, photos) {
                    val existing = album?.photoIds?.toSet().orEmpty()
                    photos.filter { it.id !in existing }
                }
                PickPhotosScreen(
                    title = "Добавить фото",
                    showName = false,
                    confirmLabel = "Добавить",
                    photos = available,
                    onClose = { nav.popBackStack() },
                    onConfirm = { _, ids, _ ->
                        vm.addPhotos(id, ids)
                        nav.popBackStack()
                    },
                )
            }

            composable(
                "viewer/{source}/{index}",
                arguments = listOf(
                    navArgument("source") { type = NavType.StringType },
                    navArgument("index") { type = NavType.IntType },
                ),
            ) { entry ->
                val source = entry.arguments?.getString("source").orEmpty()
                val index = entry.arguments?.getInt("index") ?: 0
                if (source == "all") {
                    ViewerScreen(photos = photos, startIndex = index, onBack = { nav.popBackStack() })
                } else {
                    val album = albums.firstOrNull { it.id == source }
                    val albumPhotos = remember(album, photos) {
                        val byId = photos.associateBy { it.id }
                        album?.photoIds?.mapNotNull { byId[it] }.orEmpty()
                    }
                    ViewerScreen(
                        photos = albumPhotos,
                        startIndex = index,
                        onBack = { nav.popBackStack() },
                        onRemove = { vm.removePhoto(source, it.id) },
                    )
                }
            }
        }

        if (showBar) {
            BottomBar(
                current = if (route == "photos") 1 else 0,
                onSelect = { index ->
                    val dest = if (index == 0) "albums" else "photos"
                    if (dest != route) {
                        nav.navigate(dest) {
                            popUpTo("albums") { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                },
                onAdd = { nav.navigate("create") },
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}

@Composable
private fun BottomBar(
    current: Int,
    onSelect: (Int) -> Unit,
    onAdd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PillSwitch(count = 2, selected = current, onSelect = onSelect) { index, tint ->
            Icon(
                if (index == 0) Icons.Rounded.Collections else Icons.Rounded.PhotoLibrary,
                contentDescription = if (index == 0) "Коллекции" else "Все фото",
                tint = tint,
            )
        }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier
                .size(62.dp)
                .clip(CircleShape)
                .background(Color.White)
                .clickable(onClick = onAdd),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Add, contentDescription = "Новая коллекция", tint = Color.Black, modifier = Modifier.size(30.dp))
        }
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CardFan(uris = emptyList())
        Spacer(Modifier.height(32.dp))
        Text(
            "Доступ к фотографиям",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Чтобы собирать фото в коллекции, разрешите доступ к галерее. Фото никуда не отправляются.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))
        PrimaryPill("Разрешить доступ", onRequest)
    }
}
