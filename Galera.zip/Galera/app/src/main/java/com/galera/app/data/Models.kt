package com.galera.app.data

import android.net.Uri

data class Photo(
    val id: Long,
    val uri: Uri,
    val dateMillis: Long,
)

data class Album(
    val id: String,
    val name: String,
    val createdAt: Long,
    val accentIndex: Int,
    val photoIds: List<Long>,
)
