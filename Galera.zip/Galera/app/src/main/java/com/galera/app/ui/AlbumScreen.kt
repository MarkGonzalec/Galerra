package com.galera.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesomeMosaic
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.ViewCarousel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.galera.app.data.Album
import com.galera.app.data.Photo
import kotlinx.coroutines.delay
import java.util.Calendar
import kotlin.math.absoluteValue

enum class ViewMode { Carousel, Collage, Grid }

@Composable
fun AlbumScreen(
    album: Album,
    photos: List<Photo>,
    onBack: () -> Unit,
    onOpenPhoto: (Int) -> Unit,
    onAddPhotos: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
) {
    var mode by rememberSaveable { mutableStateOf(ViewMode.Carousel) }
    var menuOpen by remember { mutableStateOf(false) }
    var renameOpen by rememberSaveable { mutableStateOf(false) }
    var deleteOpen by rememberSaveable { mutableStateOf(false) }
    val accent = Accents[album.accentIndex % Accents.size]
    val pagerState = rememberPagerState { photos.size }

    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 64.dp
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(Modifier.fillMaxSize().background(GaleraBg)) {
        // фон: акцентный градиент + (в карусели) размытое текущее фото
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.30f), GaleraBg), endY = 1500f)),
        )
        if (mode == ViewMode.Carousel && photos.isNotEmpty()) {
            Crossfade(
                targetState = photos.getOrNull(pagerState.currentPage)?.uri,
                animationSpec = tween(450),
                label = "backdrop",
            ) { uri ->
                if (uri != null) PhotoImage(uri, Modifier.fillMaxSize().alpha(0.55f), px = 20)
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.30f), GaleraBg.copy(alpha = 0.94f)))),
            )
        }

        if (photos.isEmpty()) {
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(album.name, style = MaterialTheme.typography.headlineLarge, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text("В коллекции пока пусто", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(20.dp))
                PrimaryPill("Добавить фото", onAddPhotos)
            }
        } else {
            Crossfade(targetState = mode, animationSpec = tween(280), label = "mode") { m ->
                when (m) {
                    ViewMode.Carousel -> CarouselView(
                        album = album,
                        photos = photos,
                        pagerState = pagerState,
                        topInset = topInset,
                        bottomInset = bottomInset,
                        onOpenPhoto = onOpenPhoto,
                    )
                    ViewMode.Collage -> CollageView(album, photos, topInset, bottomInset, onOpenPhoto)
                    ViewMode.Grid -> GridMode(photos, topInset, bottomInset, onOpenPhoto)
                }
            }

            PillSwitch(
                count = 3,
                selected = mode.ordinal,
                onSelect = { mode = ViewMode.entries[it] },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = bottomInset + 18.dp),
            ) { index, tint ->
                val vector = when (index) {
                    0 -> Icons.Rounded.ViewCarousel
                    1 -> Icons.Rounded.AutoAwesomeMosaic
                    else -> Icons.Rounded.GridView
                }
                Icon(vector, null, tint = tint, modifier = Modifier.size(22.dp))
            }
        }

        // верхняя панель
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlassButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад", tint = Color.White) }
            Spacer(Modifier.weight(1f))
            GlassButton(onClick = onAddPhotos) { Icon(Icons.Rounded.Add, "Добавить фото", tint = Color.White) }
            Spacer(Modifier.size(8.dp))
            Box {
                GlassButton(onClick = { menuOpen = true }) { Icon(Icons.Rounded.MoreVert, "Меню", tint = Color.White) }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Переименовать") }, onClick = { menuOpen = false; renameOpen = true })
                    DropdownMenuItem(text = { Text("Удалить коллекцию") }, onClick = { menuOpen = false; deleteOpen = true })
                }
            }
        }
    }

    if (renameOpen) {
        var text by rememberSaveable { mutableStateOf(album.name) }
        AlertDialog(
            onDismissRequest = { renameOpen = false },
            title = { Text("Переименовать") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { onRename(text); renameOpen = false }, enabled = text.isNotBlank()) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { renameOpen = false }) { Text("Отмена") } },
        )
    }
    if (deleteOpen) {
        AlertDialog(
            onDismissRequest = { deleteOpen = false },
            title = { Text("Удалить коллекцию?") },
            text = { Text("Сами фото останутся в галерее — удалится только коллекция.") },
            confirmButton = { TextButton(onClick = { deleteOpen = false; onDelete() }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { deleteOpen = false }) { Text("Отмена") } },
        )
    }
}

// ───────────────────────── карусель (как «Japan») ─────────────────────────

@Composable
private fun CarouselView(
    album: Album,
    photos: List<Photo>,
    pagerState: androidx.compose.foundation.pager.PagerState,
    topInset: androidx.compose.ui.unit.Dp,
    bottomInset: androidx.compose.ui.unit.Dp,
    onOpenPhoto: (Int) -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(top = topInset - 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            album.name,
            style = MaterialTheme.typography.headlineLarge,
            color = Color.White,
            textAlign = TextAlign.Center,
            maxLines = 2,
            modifier = Modifier.padding(horizontal = 24.dp),
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "${formatDate(album.createdAt)} · ${photos.size} фото",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.65f),
        )

        HorizontalPager(
            state = pagerState,
            contentPadding = PaddingValues(horizontal = 58.dp),
            pageSpacing = 12.dp,
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) { page ->
            PhotoCard(
                photos[page].uri,
                Modifier
                    .fillMaxSize()
                    .padding(top = 26.dp, bottom = 18.dp)
                    .graphicsLayer {
                        val signed = (page - pagerState.currentPage) - pagerState.currentPageOffsetFraction
                        val a = signed.absoluteValue.coerceIn(0f, 1f)
                        val s = lerp(1f, 0.86f, a)
                        scaleX = s
                        scaleY = s
                        alpha = lerp(1f, 0.55f, a)
                        rotationZ = signed.coerceIn(-1f, 1f) * 4f
                    }
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        onOpenPhoto(page)
                    },
                corner = 34.dp,
                px = 1080,
                elevation = 18.dp,
            )
        }

        Text(
            "${pagerState.currentPage + 1} / ${photos.size}",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.6f),
        )
        Spacer(Modifier.height(bottomInset + 18.dp + 52.dp + 24.dp))
    }
}

// ───────────────────────── коллаж (как «Molly») ─────────────────────────

@Composable
private fun CollageView(
    album: Album,
    photos: List<Photo>,
    topInset: androidx.compose.ui.unit.Dp,
    bottomInset: androidx.compose.ui.unit.Dp,
    onOpenPhoto: (Int) -> Unit,
) {
    val ratios = remember { listOf(0.75f, 0.92f, 0.7f, 1f) }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 22.dp, end = 22.dp, top = topInset, bottom = bottomInset + 130.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    yearOf(album.createdAt),
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.55f),
                )
                Text(
                    album.name,
                    fontFamily = Display,
                    fontWeight = FontWeight.Bold,
                    fontSize = 44.sp,
                    lineHeight = 48.sp,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                )
                Text(
                    "${photos.size} фото",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.6f),
                )
            }
        }
        itemsIndexed(photos, key = { _, p -> p.id }) { index, photo ->
            val rotation = ((photo.id % 9).toInt() - 4) * 1.6f
            val ratio = ratios[(photo.id % 4).toInt()]
            var shown by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                delay((index % 6) * 60L)
                shown = true
            }
            val scale by animateFloatAsState(
                if (shown) 1f else 0.7f,
                spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessLow),
                label = "collageScale",
            )
            val alpha by animateFloatAsState(if (shown) 1f else 0f, tween(300), label = "collageAlpha")
            PhotoCard(
                photo.uri,
                Modifier
                    .padding(top = if (index % 2 == 1) 30.dp else 0.dp)
                    .aspectRatio(ratio)
                    .graphicsLayer {
                        rotationZ = rotation
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                    }
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        onOpenPhoto(index)
                    },
                corner = 22.dp,
                px = 600,
                elevation = 14.dp,
            )
        }
    }
}

// ───────────────────────── сетка ─────────────────────────

@Composable
private fun GridMode(
    photos: List<Photo>,
    topInset: androidx.compose.ui.unit.Dp,
    bottomInset: androidx.compose.ui.unit.Dp,
    onOpenPhoto: (Int) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 3.dp, end = 3.dp, top = topInset, bottom = bottomInset + 130.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        itemsIndexed(photos, key = { _, p -> p.id }) { index, photo ->
            PhotoImage(
                photo.uri,
                Modifier
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { onOpenPhoto(index) },
                px = 360,
            )
        }
    }
}

private fun yearOf(ms: Long): String =
    Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.YEAR).toString()
