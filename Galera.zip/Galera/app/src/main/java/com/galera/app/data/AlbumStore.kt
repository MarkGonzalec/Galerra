package com.galera.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Хранит коллекции в простом JSON-файле во внутренней памяти приложения. */
class AlbumStore(context: Context) {

    private val file = File(context.filesDir, "albums.json")

    fun load(): List<Album> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ids = o.getJSONArray("ids")
                Album(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    createdAt = o.getLong("createdAt"),
                    accentIndex = o.getInt("accent"),
                    photoIds = (0 until ids.length()).map { ids.getLong(it) },
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(albums: List<Album>) {
        val arr = JSONArray()
        albums.forEach { a ->
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("name", a.name)
                    .put("createdAt", a.createdAt)
                    .put("accent", a.accentIndex)
                    .put("ids", JSONArray(a.photoIds)),
            )
        }
        runCatching { file.writeText(arr.toString()) }
    }
}
