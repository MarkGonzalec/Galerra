package com.galera.app.ui

import android.net.Uri
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.lerp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.size.Scale
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PhotoImage(
    model: Any?,
    modifier: Modifier = Modifier,
    px: Int = 480,
    contentScale: ContentScale = ContentScale.Crop,
) {
    val context = LocalContext.current
    val request = remember(model, px, contentScale) {
        ImageRequest.Builder(context)
            .data(model)
            .size(px)
            .scale(if (contentScale == ContentScale.Fit) Scale.FIT else Scale.FILL)
            .crossfade(true)
            .build()
    }
    AsyncImage(
        model = request,
        contentDescription = null,
        contentScale = contentScale,
        modifier = modifier,
    )
}

/** Карточка-фото: скругление, тонкая светлая обводка и мягкая тень. */
@Composable
fun PhotoCard(
    model: Any?,
    modifier: Modifier = Modifier,
    corner: Dp = 18.dp,
    px: Int = 480,
    elevation: Dp = 10.dp,
) {
    val shape = RoundedCornerShape(corner)
    Box(
        modifier
            .shadow(elevation, shape)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, Color.White.copy(alpha = 0.14f), shape),
    ) {
        PhotoImage(model, Modifier.fillMaxSize(), px = px)
    }
}

/**
 * Карточка «+N» — матовая, размытая. Размытие делаем декодированием крошечной
 * версии фото (16 px) и растягиванием: работает одинаково на Android 11 и новее
 * (Modifier.blur есть только с Android 12).
 */
@Composable
fun MoreCard(
    model: Any?,
    extra: Int,
    modifier: Modifier = Modifier,
    corner: Dp = 18.dp,
) {
    val shape = RoundedCornerShape(corner)
    Box(
        modifier
            .shadow(10.dp, shape)
            .clip(shape)
            .border(1.dp, Color.White.copy(alpha = 0.18f), shape),
        contentAlignment = Alignment.Center,
    ) {
        PhotoImage(model, Modifier.fillMaxSize(), px = 16)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.34f)))
        Text("+$extra", color = Color.White, fontFamily = Display, fontSize = 22.sp)
    }
}

/** Градиентная заглушка, когда фото ещё нет. */
@Composable
fun PlaceholderCard(color: Color, modifier: Modifier = Modifier, corner: Dp = 18.dp) {
    val shape = RoundedCornerShape(corner)
    Box(
        modifier
            .shadow(10.dp, shape)
            .clip(shape)
            .background(Brush.linearGradient(listOf(color.copy(alpha = 0.9f), color.copy(alpha = 0.35f))))
            .border(1.dp, Color.White.copy(alpha = 0.18f), shape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.Collections, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(28.dp))
    }
}

/**
 * Обложка коллекции из референсов: ряд наклонённых карточек внахлёст,
 * последняя — матовая «+N». Карточки «раскладываются» из стопки пружиной.
 */
@Composable
fun CoverRow(
    uris: List<Uri>,
    total: Int,
    accent: Color,
    modifier: Modifier = Modifier,
    onAdd: (() -> Unit)? = null,
) {
    val panel = RoundedCornerShape(30.dp)
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        appear.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessLow))
    }

    Box(
        modifier
            .fillMaxWidth()
            .clip(panel)
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.28f), accent.copy(alpha = 0.08f))))
            .border(1.dp, accent.copy(alpha = 0.20f), panel)
            .padding(horizontal = 14.dp, vertical = 20.dp),
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val slots = minOf(total, 4).coerceAtLeast(1)
            val cw = maxWidth * 0.30f
            val ch = cw * 1.38f
            val step = if (slots > 1) minOf((maxWidth - cw) / (slots - 1), cw * 0.80f) else 0.dp
            val span = step * (slots - 1) + cw
            val startX = (maxWidth - span) / 2
            val centerX = (maxWidth - cw) / 2
            val rotations = listOf(-6f, 3f, -3f, 5f)

            Box(Modifier.fillMaxWidth().height(ch + 8.dp), contentAlignment = Alignment.CenterStart) {
                if (total == 0) {
                    PlaceholderCard(
                        accent,
                        Modifier.align(Alignment.Center).size(cw, ch).graphicsLayer { rotationZ = -4f },
                    )
                }
                for (i in 0 until if (total == 0) 0 else slots) {
                    val cardMod = Modifier
                        .zIndex(i.toFloat())
                        .offset { IntOffset(lerp(centerX, startX + step * i, appear.value).roundToPx(), 0) }
                        .size(cw, ch)
                        .graphicsLayer { rotationZ = rotations[i % rotations.size] * appear.value }
                    val uri = uris.getOrNull(i)
                    if (total > 4 && i == 3) {
                        MoreCard(uri, total - 3, cardMod)
                    } else {
                        PhotoCard(uri, cardMod, px = 360)
                    }
                }
            }
        }

        if (onAdd != null) {
            GlassButton(
                onClick = onAdd,
                size = 36.dp,
                modifier = Modifier.align(Alignment.TopEnd).offset(x = 4.dp, y = (-10).dp).zIndex(10f),
            ) {
                Icon(Icons.Rounded.Add, "Добавить фото", tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
    }
}

/** Круглая «стеклянная» кнопка (плюс, назад, меню). */
@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    content: @Composable () -> Unit,
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.12f))
            .border(1.dp, Color.White.copy(alpha = 0.10f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

/**
 * Плавающая «пилюля» с переключателем — для нижней навигации и смены режима просмотра.
 * [icon] получает индекс и текущий цвет иконки.
 */
@Composable
fun PillSwitch(
    count: Int,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable (index: Int, tint: Color) -> Unit,
) {
    Row(
        modifier
            .clip(CircleShape)
            .background(GaleraPill.copy(alpha = 0.95f))
            .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape)
            .padding(6.dp),
    ) {
        for (i in 0 until count) {
            val isSel = i == selected
            val bg by animateColorAsState(if (isSel) Color.White else Color.Transparent, label = "pillBg")
            val tint by animateColorAsState(
                if (isSel) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant,
                label = "pillTint",
            )
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(bg)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) { icon(i, tint) }
        }
    }
}

/** Белая «таблетка»-кнопка действия. */
@Composable
fun PrimaryPill(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Box(
        modifier
            .height(56.dp)
            .clip(CircleShape)
            .background(Color.White)
            .alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.Black, style = MaterialTheme.typography.labelLarge)
    }
}

fun formatDate(ms: Long): String =
    SimpleDateFormat("d MMM yyyy", Locale("ru")).format(Date(ms))
